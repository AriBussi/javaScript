/*
GAME RULES:

- The game has 2 players, playing in rounds
- In each turn, a player rolls a dice as many times as he whishes. Each result get added to his ROUND score
- BUT, if the player rolls a 1, all his ROUND score gets lost. After that, it's the next player's turn
- The player can choose to 'Hold', which means that his ROUND score gets added to his GOLBAL score. After that, it's the next player's turn
- The first player to reach 100 points on GLOBAL score wins the game

*/

// Variables
var scores, activePlayer, roundScore, gameOn, preRound;

preRound = false;

// Funciones

function init() {
    gameOn = true;
    scores = [0, 0];
    roundScore = 0;
    activePlayer = 0;
    document.querySelector('.player-0-panel').classList.remove('winner');
    document.querySelector('.player-1-panel').classList.remove('winner');
    document.querySelector('.player-0-panel').classList.remove('active');
    document.querySelector('.player-1-panel').classList.remove('active');
    document.querySelector('.player-0-panel').classList.add('active');
    document.querySelector('.dice').style.display = 'none';
    document.querySelector('.dice2').style.display = 'none';
    document.getElementById('score-0').textContent = 0;
    document.getElementById('score-1').textContent = 0;
    document.getElementById('current-0').textContent = 0;
    document.getElementById('current-1').textContent = 0;
    document.getElementById('name-0').textContent = 'Player 1';
    document.getElementById('name-1').textContent = 'Player 2';
    preRound = false;
}

function nextPlayer() {
    document.getElementById('current-' + activePlayer).textContent = 0;
    activePlayer === 0 ? activePlayer = 1 : activePlayer = 0;
    roundScore = 0;
    document.querySelector('.player-0-panel').classList.toggle('active');
    document.querySelector('.player-1-panel').classList.toggle('active');
    preRound = false;   
}




// Preseteos
init();

// Botón "Roll Dice"
document.querySelector('.btn-roll').addEventListener('click', function() {
   if (gameOn){
    var dice = Math.floor(Math.random() * 6) + 1;
    var dice2 = Math.floor(Math.random() * 6) + 1;
    var diceDOM = document.querySelector('.dice');
    var diceDOM2 = document.querySelector('.dice2');

   
    diceDOM.style.display = 'block';
    diceDOM.src = ('dice-' + dice + '.png');
    diceDOM2.style.display = 'block';
    diceDOM2.src = ('dice-' + dice2 + '.png');

    if (dice === 1 || dice2 === 1) {
        nextPlayer();
    } else if (dice === 6){
        if (preRound) {
            document.querySelector('#current-' + activePlayer).textContent = 0;
            document.getElementById('score-' + activePlayer).textContent = 0;
            nextPlayer();
        } else {
            preRound = true;
            roundScore += dice + dice2;
            document.querySelector('#current-' + activePlayer).textContent = roundScore;
        }
    } else {
        roundScore += dice + dice2;
        document.querySelector('#current-' + activePlayer).textContent = roundScore;
        preRound = false;           
    } 
}
});

// Botón "Hold"

document.querySelector('.btn-hold').addEventListener('click', function(){
    if (gameOn){
        scores[activePlayer] += roundScore;
        document.getElementById('score-' + activePlayer).textContent = scores[activePlayer];
        preRound = false;

        var input = document.querySelector('.winning-score').value;
        var winningScore;
        if(input){
            winningScore = input;
        } else {
            winningScore = 100;
        }
    
        if (scores[activePlayer] >= winningScore){
            document.querySelector('#name-' + activePlayer).textContent = 'Winner!';
            document.querySelector('.dice').style.display = 'none';
            document.querySelector('.player-' + activePlayer + '-panel').classList.add('winner');
            document.querySelector('.player-' + activePlayer + '-panel').classList.remove('active');
            gameOn = false;   
        } else { 
            nextPlayer();
        }
    }
});

// Botón "New game"
document.querySelector('.btn-new').addEventListener('click', init);
